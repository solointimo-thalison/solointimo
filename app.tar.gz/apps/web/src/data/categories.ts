export const brandLogo = 'https://horizons-cdn.hostinger.com/be4ff0db-d4e2-41df-9407-2dbd2d4a9905/4fe82c23db822c1a28f33f73f2174313.jpg';
export const whatsappUrl = 'https://wa.me/5592981151212';
export const instagramUrl = 'https://www.instagram.com/solointimo/';
export const facebookUrl = 'https://www.facebook.com/solointimo/';

export const storeAddress = 'R. Joaquim Sarmento, 190 - Centro - Manaus - AM, 69010-020';
export const storeMapsUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent('R. Joaquim Sarmento, 190, Centro, Manaus, AM, 69010-020');

export const categories = [
  { name: 'Soutiens', brand: 'Hope & Duloren', brandUrl: 'https://www.hopeoficial.com.br/sutias/meia-taca', text: 'Delicadeza e conforto para acompanhar você.', image: 'https://images.hostinger.com/078d87d9-cc65-49f0-829b-e8e96e19a493.png', alt: 'Composição editorial de soutiens em tons suaves e vinho' },
  { name: 'Calcinhas', brand: 'Duloren', brandUrl: 'https://www.duloren.com.br/calcinhas', text: 'O cuidado que começa nos pequenos detalhes.', image: 'https://images.hostinger.com/54eaa370-db61-4d62-a85f-9cb1cc4d6d10.png', alt: 'Composição editorial de calcinhas em tons neutros e vinho' },
  { name: 'Cuecas', brand: 'Lupo', brandUrl: 'https://www.lupo.com.br/masculino/cuecas/boxer', text: 'Bem-estar para todos os momentos do dia.', image: 'https://images.hostinger.com/6075fcd1-4cef-42f6-9645-6213f221933a.png', alt: 'Composição editorial de cuecas de algodão dobradas' },
  { name: 'Pijamas', brand: 'Paulienne', brandUrl: 'https://www.paulienne.com.br/', text: 'Para desacelerar e se sentir em casa.', image: 'https://images.tcdn.com.br/img/img_prod/627000/camisola_clssica_manga_curta_em_liganete_amni_5_20260827145702_ca9be3be54dc.jpg', alt: 'Camisola de pijama Paulienne em liganete' },
  { name: 'Pantufas', brand: '', brandUrl: '', text: 'Um toque de aconchego a cada passo.', image: 'https://images.hostinger.com/acae4527-f063-43f9-bfbc-f37050609a7c.png', alt: 'Composição editorial de pantufas macias em tom creme' },
  { name: 'Acessórios', brand: 'Bianca Accessory', brandUrl: 'https://www.biancastore.com.br/prendedor/', text: 'Detalhes que completam o seu cuidado.', image: 'https://acdn-us.mitiendanube.com/stores/006/040/232/products/bianca_accessory_prendedor_madrid_medium_acessorio_de_cabelo-17-569af0f7aae6fa976d17492389478705-1024-1024.webp', alt: 'Prendedor de cabelo Bianca Accessory' },
  { name: 'Moda Praia', brand: 'Banho de Mar', brandUrl: 'https://banhodemar.com.br/m', text: 'Leveza para aproveitar os dias de sol.', image: 'https://img.irroba.com.br/fit-in/250x250/filters:format(webp):fill(fff):quality(80)/banhiaao/catalog/bm26/0623542-1096-1.jpg', alt: 'Maiô de moda praia Banho de Mar' },
  { name: 'Moda Infantil', brand: 'DelRio', brandUrl: 'https://www.delrio.com.br/kids', text: 'Carinho e conforto para os pequenos.', image: 'https://delrio.vtexassets.com/assets/vtex.file-manager-graphql/images/f7c0a99e-6f59-477f-8b74-b4757fa8c4bb___15f460661acb797cef41fde66bce402f.jpg', alt: 'Moda infantil DelRio para meninos' },
];
